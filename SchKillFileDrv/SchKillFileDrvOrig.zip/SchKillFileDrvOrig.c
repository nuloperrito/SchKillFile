#include <ntifs.h>
#include <ntddk.h>
#include <ntstrsafe.h>
#include "../common.h"

// Context for the system worker thread
typedef struct _WORK_ITEM_CTX {
    PIO_WORKITEM   WorkItem;
    PIRP           Irp;
    ULONG          IoControlCode;
    ULONG          PathLength; // Length in bytes
    WCHAR          PathBuffer[1]; // Variable length
} WORK_ITEM_CTX, * PWORK_ITEM_CTX;

// Context for iterative directory traversal
typedef struct _DIR_NODE {
    LIST_ENTRY     ListEntry;
    UNICODE_STRING Path;
} DIR_NODE, * PDIR_NODE;

VOID SchUnloadDriver(
    IN PDRIVER_OBJECT DriverObject)
{
    PDEVICE_OBJECT deviceObject = DriverObject->DeviceObject;
    UNICODE_STRING uniSymLink;

    RtlInitUnicodeString(&uniSymLink, DOS_DEVICE_NAME);
    IoDeleteSymbolicLink(&uniSymLink);
    IoDeleteDevice(deviceObject);
}

HANDLE
SchOpenFile(
    IN PCWSTR FileName,
    IN ACCESS_MASK DesiredAccess,
    IN ULONG ShareAccess)
{
    NTSTATUS ntStatus;
    UNICODE_STRING uniFileName;
    OBJECT_ATTRIBUTES objectAttributes;
    HANDLE ntFileHandle;
    IO_STATUS_BLOCK ioStatus;

    if (KeGetCurrentIrql() > PASSIVE_LEVEL)
    {
        KdPrint(("Do Not At PASSIVE_LEVEL!\n"));
        return 0;
    }

    RtlInitUnicodeString(&uniFileName, FileName);

    InitializeObjectAttributes(&objectAttributes, &uniFileName,
        OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

    ntStatus = IoCreateFile(&ntFileHandle,
        DesiredAccess,
        &objectAttributes,
        &ioStatus,
        0,
        FILE_ATTRIBUTE_NORMAL,
        ShareAccess,
        FILE_OPEN,
        FILE_SYNCHRONOUS_IO_NONALERT,
        NULL,
        0,
        0,
        NULL,
        IO_NO_PARAMETER_CHECKING);

    if (!NT_SUCCESS(ntStatus))
    {
        KdPrint(("IoCreateFile Error\n"));
        return 0;
    }

    return ntFileHandle;
}

NTSTATUS
SchSetInformationCompletion(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp,
    IN PVOID Context)
{
    Irp->UserIosb->Status = Irp->IoStatus.Status;
    Irp->UserIosb->Information = Irp->IoStatus.Information;

    KeSetEvent(Irp->UserEvent, IO_NO_INCREMENT, FALSE);

    IoFreeIrp(Irp);
    return STATUS_MORE_PROCESSING_REQUIRED;
}

BOOLEAN
SchKillSingleFile(
    IN HANDLE FileHandle)
{
    NTSTATUS ntStatus = STATUS_SUCCESS;
    PFILE_OBJECT fileObject;
    PDEVICE_OBJECT DeviceObject;
    PIRP Irp;
    KEVENT event;
    FILE_DISPOSITION_INFORMATION FileInformation;
    IO_STATUS_BLOCK ioStatus;
    PIO_STACK_LOCATION irpSp;

    ntStatus = ObReferenceObjectByHandle(FileHandle,
        DELETE,
        *IoFileObjectType,
        KernelMode,
        &fileObject,
        NULL);

    if (!NT_SUCCESS(ntStatus))
    {
        return FALSE;
    }

    DeviceObject = IoGetRelatedDeviceObject(fileObject);
    Irp = IoAllocateIrp(DeviceObject->StackSize, TRUE);

    if (Irp == NULL)
    {
        ObDereferenceObject(fileObject);
        return FALSE;
    }

    KeInitializeEvent(&event, SynchronizationEvent, FALSE);

    FileInformation.DeleteFile = TRUE;

    Irp->AssociatedIrp.SystemBuffer = &FileInformation;
    Irp->UserEvent = &event;
    Irp->UserIosb = &ioStatus;
    Irp->Tail.Overlay.OriginalFileObject = fileObject;
    Irp->Tail.Overlay.Thread = (PETHREAD)KeGetCurrentThread();
    Irp->RequestorMode = KernelMode;

    irpSp = IoGetNextIrpStackLocation(Irp);
    irpSp->MajorFunction = IRP_MJ_SET_INFORMATION;
    irpSp->DeviceObject = DeviceObject;
    irpSp->FileObject = fileObject;
    irpSp->Parameters.SetFile.Length = sizeof(FILE_DISPOSITION_INFORMATION);
    irpSp->Parameters.SetFile.FileInformationClass = FileDispositionInformation;
    irpSp->Parameters.SetFile.FileObject = fileObject;

    IoSetCompletionRoutine(
        Irp,
        SchSetInformationCompletion,
        &event,
        TRUE,
        TRUE,
        TRUE);

    if (fileObject->SectionObjectPointer != NULL) {
        MmFlushImageSection(fileObject->SectionObjectPointer, MmFlushForDelete);
        CcPurgeCacheSection(fileObject->SectionObjectPointer, NULL, 0, FALSE);
    }

    IoCallDriver(DeviceObject, Irp);
    KeWaitForSingleObject(&event, Executive, KernelMode, TRUE, NULL);

    ObDereferenceObject(fileObject);

    return TRUE;
}

BOOLEAN
SchDeleteFolderIterative(
    IN PCWSTR RootPath
)
{
    NTSTATUS status;
    LIST_ENTRY dirListHead; // List of all directories found
    PDIR_NODE rootNode = NULL;
    BOOLEAN result = TRUE;

    InitializeListHead(&dirListHead);

    // 1. Initialize root node
    rootNode = (PDIR_NODE)ExAllocatePoolWithTag(PagedPool, sizeof(DIR_NODE), 'doND');
    if (!rootNode) return FALSE;

    if (!NT_SUCCESS(RtlCreateUnicodeString(&rootNode->Path, RootPath))) {
        ExFreePool(rootNode);
        return FALSE;
    }
    InsertTailList(&dirListHead, &rootNode->ListEntry);

    // 2. Pass 1: Traverse list, delete files, add subdirs to list (BFS)
    // We iterate through the list as we append to it.
    PLIST_ENTRY pEntry = dirListHead.Flink;

    while (pEntry != &dirListHead) {
        PDIR_NODE currentNode = CONTAINING_RECORD(pEntry, DIR_NODE, ListEntry);

        HANDLE hDir = NULL;
        OBJECT_ATTRIBUTES objAttr;
        IO_STATUS_BLOCK ioSt;
        PFILE_FULL_DIR_INFORMATION pInfo = NULL;
        ULONG bufLen = 4096; // 4KB buffer

        InitializeObjectAttributes(&objAttr, &currentNode->Path,
            OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE, NULL, NULL);

        // Open directory
        status = ZwOpenFile(&hDir,
            FILE_LIST_DIRECTORY | SYNCHRONIZE,
            &objAttr, &ioSt,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            FILE_DIRECTORY_FILE | FILE_OPEN_FOR_BACKUP_INTENT | FILE_SYNCHRONOUS_IO_NONALERT);

        if (NT_SUCCESS(status)) {
            pInfo = ExAllocatePoolWithTag(NonPagedPool, bufLen, 'DfMz');
            if (pInfo) {
                BOOLEAN restartScan = TRUE;
                while (TRUE) {
                    status = ZwQueryDirectoryFile(hDir, NULL, NULL, NULL, &ioSt,
                        pInfo, bufLen, FileFullDirectoryInformation,
                        FALSE, NULL, restartScan);

                    restartScan = FALSE;
                    if (!NT_SUCCESS(status) || ioSt.Information == 0) break;

                    PFILE_FULL_DIR_INFORMATION pCur = pInfo;
                    do {
                        // Skip . and ..
                        BOOLEAN isDot = (pCur->FileNameLength == 2 && pCur->FileName[0] == L'.') ||
                            (pCur->FileNameLength == 4 && pCur->FileName[0] == L'.' && pCur->FileName[1] == L'.');

                        if (!isDot) {
                            // Construct full path
                            UNICODE_STRING subPath;
                            USHORT newLen = currentNode->Path.Length + sizeof(WCHAR) + (USHORT)pCur->FileNameLength;
                            subPath.MaximumLength = newLen + sizeof(WCHAR);
                            subPath.Buffer = ExAllocatePoolWithTag(PagedPool, subPath.MaximumLength, 'htPS');
                            subPath.Length = 0;

                            if (subPath.Buffer) {
                                RtlCopyUnicodeString(&subPath, &currentNode->Path);
                                if (subPath.Buffer[subPath.Length / 2 - 1] != L'\\') {
                                    RtlAppendUnicodeToString(&subPath, L"\\");
                                }
                                RtlAppendUnicodeToString(&subPath, (PCWSTR)pCur->FileName);
                                RtlCopyMemory((PUCHAR)subPath.Buffer + currentNode->Path.Length + ((currentNode->Path.Buffer[currentNode->Path.Length / 2 - 1] == L'\\') ? 0 : 2),
                                    pCur->FileName, pCur->FileNameLength);
                                subPath.Length = newLen;
                                subPath.Buffer[subPath.Length / 2] = L'\0';

                                // LOGIC: 
                                // If Directory AND NOT ReparsePoint -> Add to list (Traverse deeper)
                                // If File OR ReparsePoint -> Delete immediately (Don't follow links)
                                BOOLEAN isDir = (pCur->FileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
                                BOOLEAN isReparse = (pCur->FileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0;

                                if (isDir && !isReparse) {
                                    PDIR_NODE newNode = ExAllocatePoolWithTag(PagedPool, sizeof(DIR_NODE), 'doND');
                                    if (newNode) {
                                        newNode->Path = subPath; // Transfer ownership of buffer
                                        InsertTailList(&dirListHead, &newNode->ListEntry);
                                    }
                                    else {
                                        RtlFreeUnicodeString(&subPath);
                                    }
                                }
                                else {
                                    // It is a File or a Reparse Point (Symlink/Junction)
                                    // Delete it directly. 
                                    HANDLE hFile = SchOpenFile(subPath.Buffer, DELETE,
                                        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE);
                                    if (hFile) {
                                        SchKillSingleFile(hFile);
                                        ZwClose(hFile);
                                    }
                                    RtlFreeUnicodeString(&subPath);
                                }
                            }
                        }

                        if (pCur->NextEntryOffset == 0) break;
                        pCur = (PFILE_FULL_DIR_INFORMATION)((PUCHAR)pCur + pCur->NextEntryOffset);
                    } while (TRUE);
                }
                ExFreePool(pInfo);
            }
            ZwClose(hDir);
        }

        // Move to next directory in the list
        pEntry = pEntry->Flink;
    }

    // 3. Pass 2: Reverse traversal (Delete directories from bottom up)
    while (!IsListEmpty(&dirListHead)) {
        PLIST_ENTRY pTail = RemoveTailList(&dirListHead);
        PDIR_NODE node = CONTAINING_RECORD(pTail, DIR_NODE, ListEntry);

        // Try to delete the directory itself
        // It should be empty now unless handles are held by other procs
        HANDLE hDirToDelete = SchOpenFile(node->Path.Buffer, DELETE,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE);

        if (hDirToDelete) {
            SchKillSingleFile(hDirToDelete);
            ZwClose(hDirToDelete);
        }

        // Cleanup memory
        RtlFreeUnicodeString(&node->Path);
        ExFreePool(node);
    }

    return result;
}

VOID
SchWorkItemRoutine(
    IN PDEVICE_OBJECT DeviceObject,
    IN PVOID Context
)
{
    PWORK_ITEM_CTX ctx = (PWORK_ITEM_CTX)Context;
    NTSTATUS status = STATUS_SUCCESS;

    // Ensure we are at PASSIVE_LEVEL (WorkItems usually are, but good check)
    PAGED_CODE();

    KdPrint(("[SDKrn] Worker executing for: %S\n", ctx->PathBuffer));

    if (ctx->IoControlCode == IOCTL_DELETEFILE)
    {
        HANDLE hFile = SchOpenFile(ctx->PathBuffer, FILE_READ_ATTRIBUTES, FILE_SHARE_DELETE);
        if (hFile) {
            if (SchKillSingleFile(hFile)) {
                status = STATUS_SUCCESS;
            }
            else {
                status = STATUS_ACCESS_DENIED;
            }
            ZwClose(hFile);
        }
        else {
            status = STATUS_OBJECT_NAME_NOT_FOUND;
        }
    }
    else if (ctx->IoControlCode == IOCTL_DELETEFOLDER)
    {
        if (SchDeleteFolderIterative(ctx->PathBuffer)) {
            status = STATUS_SUCCESS;
        }
        else {
            status = STATUS_UNSUCCESSFUL;
        }
    }

    // Complete the IRP
    ctx->Irp->IoStatus.Status = status;
    ctx->Irp->IoStatus.Information = 0;
    IoCompleteRequest(ctx->Irp, IO_NO_INCREMENT);

    // Cleanup
    IoFreeWorkItem(ctx->WorkItem);
    ExFreePool(ctx);
}

NTSTATUS
DispatchCreate(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp)
{
    pIrp->IoStatus.Status = STATUS_SUCCESS;
    pIrp->IoStatus.Information = 0;

    KdPrint(("[SDKrn] IRP_MJ_CREATE\r\n"));

    IoCompleteRequest(pIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

NTSTATUS
DispatchClose(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp)
{
    pIrp->IoStatus.Status = STATUS_SUCCESS;
    pIrp->IoStatus.Information = 0;

    KdPrint(("[SDKrn] IRP_MJ_CLOSE\r\n"));

    IoCompleteRequest(pIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

NTSTATUS
DispatchDeviceControl(IN PDEVICE_OBJECT pDevObj, IN PIRP pIrp)
{
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    PIO_STACK_LOCATION pIrpStack = IoGetCurrentIrpStackLocation(pIrp);
    ULONG uIoControlCode = pIrpStack->Parameters.DeviceIoControl.IoControlCode;
    PVOID pIoBuffer = pIrp->AssociatedIrp.SystemBuffer;
    ULONG uInSize = pIrpStack->Parameters.DeviceIoControl.InputBufferLength;

    switch (uIoControlCode)
    {
    case IOCTL_DELETEFILE:
    case IOCTL_DELETEFOLDER:
    {
        // 1. Basic validation
        if (uInSize < sizeof(WCHAR) || pIoBuffer == NULL) {
            status = STATUS_INVALID_PARAMETER;
            break;
        }

        // 2. Dynamic Allocation for Context
        // Prefix "\??\" length is 4 WCHARs (8 bytes). 
        // We allocate enough for Prefix + Input + Null Terminator.
        ULONG prefixLen = 4 * sizeof(WCHAR);
        ULONG totalSize = sizeof(WORK_ITEM_CTX) + prefixLen + uInSize + sizeof(WCHAR);

        PWORK_ITEM_CTX pCtx = ExAllocatePoolWithTag(NonPagedPool, totalSize, 'kWrW');
        if (!pCtx) {
            status = STATUS_INSUFFICIENT_RESOURCES;
            break;
        }

        // 3. Prepare Context
        pCtx->IoControlCode = uIoControlCode;
        pCtx->Irp = pIrp;
        pCtx->WorkItem = IoAllocateWorkItem(pDevObj);

        if (!pCtx->WorkItem) {
            ExFreePool(pCtx);
            status = STATUS_INSUFFICIENT_RESOURCES;
            break;
        }

        // 4. Copy Path safely and Prepend Prefix
        RtlZeroMemory(pCtx->PathBuffer, prefixLen + uInSize + sizeof(WCHAR));
        RtlStringCbCopyW(pCtx->PathBuffer, totalSize, L"\\??\\");

        // Append user buffer (be careful of missing null in user buffer)
        RtlStringCbCatNW(pCtx->PathBuffer, totalSize, (PCWSTR)pIoBuffer, uInSize);

        // 5. Queue Work Item
        IoMarkIrpPending(pIrp);
        IoQueueWorkItem(pCtx->WorkItem, SchWorkItemRoutine, DelayedWorkQueue, pCtx);

        return STATUS_PENDING;
    }
    default:
        // Keep existing default logic...
        status = STATUS_INVALID_PARAMETER;
        break;
    }

    if (status != STATUS_PENDING) {
        pIrp->IoStatus.Status = status;
        pIrp->IoStatus.Information = 0;
        IoCompleteRequest(pIrp, IO_NO_INCREMENT);
    }

    return status;
}

NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT DriverObject,
    IN PUNICODE_STRING RegistryPath)
{
    UNICODE_STRING uniDeviceName;
    UNICODE_STRING uniSymLink;
    NTSTATUS ntStatus;
    PDEVICE_OBJECT deviceObject = NULL;
    HANDLE hFileHandle;

    RtlInitUnicodeString(&uniDeviceName, NT_DEVICE_NAME);
    RtlInitUnicodeString(&uniSymLink, DOS_DEVICE_NAME);

    ntStatus = IoCreateDevice(
        DriverObject,
        0,
        &uniDeviceName,
        FILE_DEVICE_UNKNOWN,
        FILE_DEVICE_SECURE_OPEN,
        FALSE,
        &deviceObject);

    if (!NT_SUCCESS(ntStatus))
    {
        KdPrint(("IoCreateDevice Error!\n"));
        return ntStatus;
    }

    ntStatus = IoCreateSymbolicLink(&uniSymLink, &uniDeviceName);

    if (!NT_SUCCESS(ntStatus))
    {
        UNICODE_STRING uniSymLink;

        RtlInitUnicodeString(&uniSymLink, DOS_DEVICE_NAME);
        IoDeleteSymbolicLink(&uniSymLink);

        ntStatus = IoCreateSymbolicLink(&uniSymLink, &uniDeviceName);
        if (!NT_SUCCESS(ntStatus))
        {
            KdPrint(("IoCreateSymbolicLink Error!\n"));
            IoDeleteDevice(deviceObject);
            return ntStatus;
        }
    }

    DriverObject->MajorFunction[IRP_MJ_CREATE] = DispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = DispatchClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchDeviceControl;

    DriverObject->DriverUnload = SchUnloadDriver;

    return STATUS_SUCCESS;
}